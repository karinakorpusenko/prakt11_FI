//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    val colorRed = ColorType.RED
    println(colorRed.ColorName())
    println(colorRed.NameWithLightness())
    println(colorRed.WarmlessWithNameWithLightness())
    println(colorRed.Meaning())

    val colorBlue = ColorType.BLUE
    println(colorBlue.ColorName())
    println(colorBlue.NameWithLightness())
    println(colorBlue.WarmlessWithNameWithLightness())
    println(colorBlue.Meaning())

    val colorGreen = ColorType.GREEN
    println(colorGreen.ColorName())
    println(colorGreen.NameWithLightness())
    println(colorGreen.WarmlessWithNameWithLightness())
    println(colorGreen.Meaning())
}